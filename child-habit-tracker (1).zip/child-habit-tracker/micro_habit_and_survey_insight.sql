-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2025 at 01:57 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+05:30"; -- Set to IST

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `micro_habit_and_survey_insight`
--

-- --------------------------------------------------------

--
-- Table structure for table `child_profiles`
--

CREATE TABLE `child_profiles` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `child_image` varchar(255) DEFAULT NULL,
  `child_name` varchar(100) NOT NULL,
  `child_age` int(11) NOT NULL,
  `child_dob` date NOT NULL,
  `blood_group` varchar(10) DEFAULT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `father_age` int(11) DEFAULT NULL,
  `mother_age` int(11) DEFAULT NULL,
  `father_contact` varchar(15) DEFAULT NULL,
  `mother_contact` varchar(15) DEFAULT NULL,
  `residential_address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`profile_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `child_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `child_profiles`
--

INSERT INTO `child_profiles` (`profile_id`, `user_id`, `child_image`, `child_name`, `child_age`, `child_dob`, `blood_group`, `father_name`, `mother_name`, `father_age`, `mother_age`, `father_contact`, `mother_contact`, `residential_address`, `created_at`, `updated_at`) VALUES
(1, 2, 'child_2_1751367164.jpg', 'User', 2, '2023-05-14', 'A+', 'User father', 'User mother', 32, 31, '1234567890', '1234567890', 'Pune, Maharashtra', '2025-06-29 06:40:37', '2025-07-01 14:12:44');

-- --------------------------------------------------------

--
-- Table structure for table `habits`
--

CREATE TABLE `habits` (
  `habit_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `habit_name` varchar(255) NOT NULL,
  `status` tinyint(1) DEFAULT 0,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`habit_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `habits_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `habits`
--

INSERT INTO `habits` (`habit_id`, `user_id`, `habit_name`, `status`, `description`, `created_at`) VALUES
(12, 2, 'ensure that child takes a 3 time proper meal', 0, '', '2025-07-01 09:54:48'),
(13, 2, 'ensure that child take a healthy diet', 0, '', '2025-07-01 09:55:33'),
(14, 2, 'read story books with child', 0, '', '2025-07-01 10:40:21'),
(15, 2, 'go on a walk with child', 0, '', '2025-07-01 10:40:26');

-- --------------------------------------------------------

--
-- Table structure for table `habit_progress`
--

CREATE TABLE `habit_progress` (
  `progress_id` int(11) NOT NULL AUTO_INCREMENT,
  `habit_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `completed_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`progress_id`),
  KEY `habit_id` (`habit_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `habit_progress_ibfk_1` FOREIGN KEY (`habit_id`) REFERENCES `habits` (`habit_id`),
  CONSTRAINT `habit_progress_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `habit_progress`
--

INSERT INTO `habit_progress` (`progress_id`, `habit_id`, `user_id`, `completed_date`, `status`) VALUES
(27, 12, 2, '2025-07-01', 0),
(28, 13, 2, '2025-07-01', 1),
(29, 12, 2, '2025-07-04', 1),
(30, 13, 2, '2025-07-04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `surveys`
--

CREATE TABLE `surveys` (
  `survey_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ease_of_habits` int(11) NOT NULL,
  `challenges` text NOT NULL,
  `survey_date` datetime NOT NULL,
  PRIMARY KEY (`survey_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `surveys_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `surveys`
--

INSERT INTO `surveys` (`survey_id`, `user_id`, `ease_of_habits`, `challenges`, `survey_date`) VALUES
(1, 2, 5, 'Lack of motivation', '2025-06-25 00:00:00'),
(2, 2, 3, 'Faced difficulty in making child sleep on time.', '2025-06-28 16:03:27'),
(3, 2, 3, 'No Challenges faced', '2025-06-29 12:27:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('parent','ngo') NOT NULL,
  `security_question` varchar(255) NOT NULL,
  `security_answer` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password_hash`, `role`, `security_question`, `security_answer`, `created_at`) VALUES
(1, 'parent-demo', '$2y$10$FxB6wS.l5yL5xYLyWWkraewEU8BveGStLDDkXN7fLq3hEgHHRE/vW', 'parent', 'What was the name of your first pet?', 'Don', '2025-06-25 05:22:42'),
(2, 'test-parent', '$2y$10$FTAPIhTXuiiJMKpF7QFCreVZRyAi2of4HrEODi62/9wYz4kBflXUi', 'parent', 'What was the name of your first pet?', 'Don', '2025-06-25 06:24:43'),
(3, 'test-ngo', '$2y$10$JrK99Q7dT8F4gvRveinjF.DJorTlw.jggYCWNbRYgjB5fkI5jt.aq', 'ngo', 'What was the name of your first pet?', 'Don', '2025-06-25 06:25:18'),
(4, 'Priyanshu', '$2y$10$UfsaDCg3Gw8PJI2BGZ1kVuVETlqRXq6MkznsKnnRTbCzUoSiGJhqu', 'parent', 'What is your mother&#39;s maiden name?', 'Red', '2025-07-02 08:51:21'),
(5, 'spaceECE', '$2y$10$wALLMQMIeFi/WMuLH1CVrOwEr2xQpwQHVDFp9cVYzl5ybGGQyjR1.', 'ngo', 'What is your mother&#39;s maiden name?', 'Red', '2025-07-02 08:53:05');

--
-- Indexes for dumped tables
--

-- (Indexes already defined in CREATE TABLE statements)

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `child_profiles`
--
ALTER TABLE `child_profiles`
  MODIFY `profile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `habits`
--
ALTER TABLE `habits`
  MODIFY `habit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `habit_progress`
--
ALTER TABLE `habit_progress`
  MODIFY `progress_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `surveys`
--
ALTER TABLE `surveys`
  MODIFY `survey_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

-- (Constraints already defined in CREATE TABLE statements)

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;