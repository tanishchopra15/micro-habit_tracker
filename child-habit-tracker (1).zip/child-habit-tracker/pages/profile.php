<?php
// Start session only if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../includes/requireRole.php';

// Prevent caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

requireRole('parent');

$parent_id = $_SESSION['user_id'] ?? null;
if (!$parent_id) {
    die("User not logged in or session invalid. <a href='/child-habit-tracker/pages/login_parent.php'>Login</a>");
}

// Unique timestamp for form action to prevent caching
$form_timestamp = time();

$success = $error = "";
$is_edit_mode = isset($_GET['edit']) && $_GET['edit'] === '1';
$is_view_mode = isset($_GET['view']) && $_GET['view'] === '1' && isset($_GET['user_id']);
$view_user_id = $is_view_mode ? filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT) : $parent_id;

if ($is_view_mode && $_SESSION['role'] !== 'ngo') {
    die("Unauthorized access.");
}

try {
    $stmt = $pdo->prepare("SELECT * FROM child_profiles WHERE user_id = ?");
    $stmt->execute([$view_user_id]);
    $profile = $stmt->fetch(PDO::FETCH_ASSOC);
    $profile_exists = $profile !== false;
    if (!$profile_exists) {
        error_log("No profile found for user_id: $view_user_id in profile.php");
    }
} catch (PDOException $e) {
    $error = "An error occurred while loading the profile.";
    error_log("Database error in profile.php (load profile): " . $e->getMessage());
    // Debug: Output the error for testing
    // var_dump($e->getMessage()); // Remove after debugging
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile']) && !$is_view_mode) {
    $child_name = filter_input(INPUT_POST, 'child_name', FILTER_SANITIZE_STRING);
    $child_age = filter_input(INPUT_POST, 'child_age', FILTER_VALIDATE_INT);
    $child_dob = filter_input(INPUT_POST, 'child_dob', FILTER_SANITIZE_STRING);
    $blood_group = filter_input(INPUT_POST, 'blood_group', FILTER_SANITIZE_STRING);
    $father_name = filter_input(INPUT_POST, 'father_name', FILTER_SANITIZE_STRING);
    $mother_name = filter_input(INPUT_POST, 'mother_name', FILTER_SANITIZE_STRING);
    $father_age = filter_input(INPUT_POST, 'father_age', FILTER_VALIDATE_INT) ?: null;
    $mother_age = filter_input(INPUT_POST, 'mother_age', FILTER_VALIDATE_INT) ?: null;
    $father_contact = filter_input(INPUT_POST, 'father_contact', FILTER_SANITIZE_STRING);
    $mother_contact = filter_input(INPUT_POST, 'mother_contact', FILTER_SANITIZE_STRING);
    $residential_address = filter_input(INPUT_POST, 'residential_address', FILTER_SANITIZE_STRING);

    // Handle image upload
    $child_image = $profile['child_image'] ?? null;
    if (isset($_FILES['child_image']) && $_FILES['child_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../Uploads/';
        $allowed_types = ['image/jpeg', 'image/png'];
        $max_size = 2 * 1024 * 1024; // 2MB
        $file_type = $_FILES['child_image']['type'];
        $file_size = $_FILES['child_image']['size'];
        $file_ext = pathinfo($_FILES['child_image']['name'], PATHINFO_EXTENSION);
        $file_name = 'child_' . $parent_id . '_' . time() . '.' . $file_ext;
        $file_path = $upload_dir . $file_name;

        if (!in_array($file_type, $allowed_types)) {
            $error = "Only JPEG and PNG images are allowed.";
        } elseif ($file_size > $max_size) {
            $error = "Image size exceeds 2MB limit.";
        } else {
            if (!is_dir($upload_dir) && !mkdir($upload_dir, 0755, true)) {
                $error = "Failed to create upload directory.";
            } elseif (!move_uploaded_file($_FILES['child_image']['tmp_name'], $file_path)) {
                $error = "Failed to upload image.";
                error_log("Image upload failed in profile.php for user $parent_id: " . print_r($_FILES['child_image'], true));
            } else {
                $child_image = $file_name;
                // Remove old image if it exists
                if ($profile['child_image'] && file_exists($upload_dir . $profile['child_image'])) {
                    unlink($upload_dir . $profile['child_image']);
                }
            }
        }
    }

    if (empty($error)) {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $child_dob)) {
            $error = "Invalid date of birth format (YYYY-MM-DD).";
        } elseif ($child_age < 0 || $child_age > 18) {
            $error = "Child age must be between 0 and 18.";
        } elseif (empty($child_name) || empty($father_name) || empty($mother_name) || empty($residential_address)) {
            $error = "Required fields cannot be empty.";
        } else {
            try {
                if ($profile_exists) {
                    $stmt = $pdo->prepare("UPDATE child_profiles SET child_image = ?, child_name = ?, child_age = ?, child_dob = ?, blood_group = ?, father_name = ?, mother_name = ?, father_age = ?, mother_age = ?, father_contact = ?, mother_contact = ?, residential_address = ?, updated_at = NOW() WHERE user_id = ?");
                    $stmt->execute([$child_image, $child_name, $child_age, $child_dob, $blood_group, $father_name, $mother_name, $father_age, $mother_age, $father_contact, $mother_contact, $residential_address, $parent_id]);
                    $success = "Profile updated successfully!";
                } else {
                    $stmt = $pdo->prepare("INSERT INTO child_profiles (user_id, child_image, child_name, child_age, child_dob, blood_group, father_name, mother_name, father_age, mother_age, father_contact, mother_contact, residential_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$parent_id, $child_image, $child_name, $child_age, $child_dob, $blood_group, $father_name, $mother_name, $father_age, $mother_age, $father_contact, $mother_contact, $residential_address]);
                    $success = "Profile created successfully!";
                }
                header("Location: profile.php?success=1");
                exit;
            } catch (PDOException $e) {
                $error = "An error occurred while saving the profile.";
                error_log("Database error in profile.php (save profile): " . $e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Micro Habit Tracker - Child Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Google Translate Script -->
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script type="text/javascript">
    function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
    }
    </script>
    <style>
        body { background-color: #FFFFFF; color: #2D3748; }
        .sidebar { background-color: #FFC107; /* Yellow */ }
        .sidebar a { color: #FFFFFF; }
        .sidebar a:hover { color: #FFD54F; /* Lighter Yellow */ }
        .content h1 { color: #FFC107; /* Yellow */ }
        .card { background-color: #FFF9C4; /* Light Yellow */ border: 1px solid #FFE082; }
        .btn { background-color: #FFC107; /* Yellow */ }
        .btn:hover { background-color: #FFB300; /* Darker Yellow */ }
        .edit-btn { background-color: #4B5563; }
        .edit-btn:hover { background-color: #374151; }
        .footer a { color: #FFD700; /* Gold */ }
        .footer a:hover { color: #FFCA28; /* Lighter Gold */ }
        .profile-img { max-width: 150px; height: auto; border-radius: 50%; object-fit: cover; }
    </style>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <a href="parent_dashboard.php" class="block py-2 hover:text-FFD54F">Dashboard</a>
        <a href="manage_habits.php" class="block py-2 hover:text-FFD54F">Manage Habits</a>
        <a href="daily_log.php" class="block py-2 hover:text-FFD54F">Daily Log</a>
        <a href="weekly_record.php" class="block py-2 hover:text-FFD54F">Weekly Record</a>
        <a href="weekly_survey.php" class="block py-2 hover:text-FFD54F">Weekly Survey</a>
        <a href="profile.php" class="block py-2 hover:text-FFD54F">Profile</a>
        <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">Child Profile</h1>
            <p class="text-lg md:text-xl mb-6">Manage your child's profile as of <span class="font-semibold"><?php echo date('h:i A T'); ?></span></p>
            <?php if (!empty($success)): ?>
                <p class="text-green-600 mb-4"><?php echo htmlspecialchars($success); ?></p>
            <?php elseif (!empty($error)): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>
        <div class="max-w-2xl mx-auto fade-in">
            <div class="card p-6">
                <form method="POST" enctype="multipart/form-data" action="profile.php?t=<?php echo $form_timestamp; ?>" class="space-y-6" <?php echo $is_view_mode ? 'onsubmit="return false;"' : ''; ?>>
                    <div class="flex flex-col items-center mb-6">
                        <?php if ($profile_exists && $profile['child_image']): ?>
                            <img src="../Uploads/<?php echo htmlspecialchars($profile['child_image']); ?>" alt="Child Image" class="profile-img mb-4">
                        <?php else: ?>
                            <div class="w-32 h-32 bg-gray-200 rounded-full flex items-center justify-center mb-4">
                                <span class="text-gray-500">No Image</span>
                            </div>
                        <?php endif; ?>
                        <input type="file" name="child_image" accept="image/jpeg,image/png" <?php echo $is_edit_mode && !$is_view_mode ? '' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block font-semibold">Child's Name</label>
                            <input type="text" name="child_name" value="<?php echo $profile_exists ? htmlspecialchars($profile['child_name']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? 'required' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Age</label>
                            <input type="number" name="child_age" value="<?php echo $profile_exists ? htmlspecialchars($profile['child_age']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? 'required min="0" max="18"' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Date of Birth</label>
                            <input type="date" name="child_dob" value="<?php echo $profile_exists ? htmlspecialchars($profile['child_dob']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? 'required' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Blood Group</label>
                            <input type="text" name="blood_group" value="<?php echo $profile_exists ? htmlspecialchars($profile['blood_group']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? '' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Father's Name</label>
                            <input type="text" name="father_name" value="<?php echo $profile_exists ? htmlspecialchars($profile['father_name']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? 'required' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Father's Age</label>
                            <input type="number" name="father_age" value="<?php echo $profile_exists ? htmlspecialchars($profile['father_age']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? '' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Mother's Name</label>
                            <input type="text" name="mother_name" value="<?php echo $profile_exists ? htmlspecialchars($profile['mother_name']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? 'required' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Mother's Age</label>
                            <input type="number" name="mother_age" value="<?php echo $profile_exists ? htmlspecialchars($profile['mother_age']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? '' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Father's Contact Number</label>
                            <input type="text" name="father_contact" value="<?php echo $profile_exists ? htmlspecialchars($profile['father_contact']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? '' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                        <div>
                            <label class="block font-semibold">Mother's Contact Number</label>
                            <input type="text" name="mother_contact" value="<?php echo $profile_exists ? htmlspecialchars($profile['mother_contact']) : ''; ?>" <?php echo $is_edit_mode && !$is_view_mode ? '' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg">
                        </div>
                    </div>
                    <div>
                        <label class="block font-semibold">Residential Address</label>
                        <textarea name="residential_address" <?php echo $is_edit_mode && !$is_view_mode ? 'required' : 'disabled'; ?> class="w-full p-2 border border-FFE082 rounded-lg" rows="4"><?php echo $profile_exists ? htmlspecialchars($profile['residential_address']) : ''; ?></textarea>
                    </div>
                    <?php if (!$is_view_mode): ?>
                        <div class="flex justify-end space-x-4">
                            <?php if ($is_edit_mode): ?>
                                <button type="submit" name="save_profile" class="btn text-white p-2 rounded-lg">Save</button>
                                <a href="profile.php" class="edit-btn text-white p-2 rounded-lg">Cancel</a>
                            <?php else: ?>
                                <a href="profile.php?edit=1" class="edit-btn text-white p-2 rounded-lg">Edit</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <p class="text-2D3748">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-2D3748 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="hover:underline">Instagram</a>
                <!-- Google Translate Element -->
                <div id="google_translate_element"></div>
            </div>
        </div>
    </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-white text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>