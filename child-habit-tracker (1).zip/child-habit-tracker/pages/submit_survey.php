<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../includes/requireRole.php';
require_once '../pages/Header.php';
session_start();

requireRole('parent');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_survey'])) {
    $parent_id = $_SESSION['user_id'];
    $ease_of_habits = filter_input(INPUT_POST, 'ease_of_habits', FILTER_VALIDATE_INT);
    $challenges = filter_input(INPUT_POST, 'challenges', FILTER_SANITIZE_STRING);

    // Debug input
    error_log("Survey submission - ease: $ease_of_habits, challenges: $challenges");

    if ($ease_of_habits !== false && $ease_of_habits >= 1 && $ease_of_habits <= 5 && !empty($challenges)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO surveys (user_id, ease_of_habits, challenges, survey_date) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$parent_id, $ease_of_habits, $challenges]);
            header("Location: weekly_survey.php?success=1");
            exit;
        } catch (PDOException $e) {
            error_log("Error submitting survey: " . $e->getMessage());
            header("Location: weekly_survey.php?error=1");
            exit;
        }
    } else {
        header("Location: weekly_survey.php?error=2");
        exit;
    }
}

// If not a POST request or missing submit_survey, redirect
header("Location: weekly_survey.php?error=3");
exit;