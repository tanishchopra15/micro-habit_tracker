<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../pages/Header.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - Welcome</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Google Translate Script -->
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script type="text/javascript">
    function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
    }
    </script>
    <style>
        body {
            background-color: #FFFFFF;
            color: #2D3748;
        }
        .sidebar {
            background-color: #FFC107; /* Yellow */
        }
        .sidebar a {
            color: #FFFFFF;
        }
        .sidebar a:hover {
            color: #FFD54F; /* Lighter Yellow */
        }
        .content h1 {
            color: #FFC107; /* Yellow */
        }
        .card {
            background-color: #FFF9C4; /* Light Yellow */
            border: 1px solid #FFE082;
        }
        .btn {
            background-color: #FFC107; /* Yellow */
        }
        .btn:hover {
            background-color: #FFB300; /* Darker Yellow */
        }
        .footer a {
            color: #FFD700; /* Gold */
        }
        .footer a:hover {
            color: #FFCA28; /* Lighter Gold */
        }
        .card img {
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .sidebar-logo {
            max-width: 150px;
            height: auto;
        }
    </style>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <a href="index.php" class="block mb-6">
            <img src="../assets/images/SpaceECE_Logo.jpg" alt="SpaceECE India Foundation Logo" class="sidebar-logo">
        </a>
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <?php if (isset($_SESSION['role'])): ?>
            <?php if ($_SESSION['role'] === 'parent'): ?>
                <a href="parent_dashboard.php" class="block py-2 hover:text-FFD54F">Dashboard</a>
                <a href="manage_habits.php" class="block py-2 hover:text-FFD54F">Manage Habits</a>
                <a href="daily_log.php" class="block py-2 hover:text-FFD54F">Daily Log</a>
                <a href="weekly_record.php" class="block py-2 hover:text-FFD54F">Weekly Record</a>
                <a href="weekly_survey.php" class="block py-2 hover:text-FFD54F">Weekly Survey</a>
                <a href="profile.php" class="block py-2 hover:text-FFD54F">Profile</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php elseif ($_SESSION['role'] === 'ngo'): ?>
                <a href="ngo_dashboard.php" class="block py-2 hover:text-FFD54F">NGO Dashboard</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php endif; ?>
        <?php else: ?>
            <a href="login_parent.php" class="block py-2 hover:text-FFD54F">Parent Login</a>
            <a href="login_ngo.php" class="block py-2 hover:text-FFD54F">NGO Login</a>
            <a href="register.php" class="block py-2 hover:text-FFD54F">Register</a>
        <?php endif; ?>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">Welcome</h1>
            <p class="text-lg md:text-xl mb-6">Join us to track your child's habits as of <span class="font-semibold"><?php echo date('h:i A T'); ?></span></p>
        </div>
        <div class="max-w-2xl mx-auto space-y-8 fade-in">
            <!-- SpaceECE India Foundation Section -->
            <div class="card p-6">
                <img src="../assets/images/SpaceECE_India_Foundation.jpg" alt="SpaceECE India Foundation" class="w-full h-48 object-cover mb-4 rounded-lg">
                <h2 class="text-xl font-semibold mb-2">About SpaceECE India Foundation</h2>
                <p>SpaceECE India Foundation is dedicated to enhancing early childhood education through innovative programs and community support. Our mission is to empower parents and educators with tools to foster healthy habits in children, creating a strong foundation for lifelong learning.</p>
            </div>
            <!-- Habit Tracker Section -->
            <div class="card p-6">
                <img src="../assets/images/Habit_Tracker.jpg" alt="Habit Tracker" class="w-full h-48 object-cover mb-4 rounded-lg">
                <h2 class="text-xl font-semibold mb-2">About Micro Habit Tracker</h2>
                <p>The Micro Habit Tracker is a tool designed to help parents monitor and encourage positive habits in their children. With features like daily logs, weekly records, and surveys, it provides insights to support your child's development effectively.</p>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <p class="text-2D3748">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-2D3748 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="hover:underline">Instagram</a>
                <!-- Google Translate Element -->
                <div id="google_translate_element"></div>
            </div>
        </div>
    </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-white text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>