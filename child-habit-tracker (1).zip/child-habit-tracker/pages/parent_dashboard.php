<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../includes/requireRole.php';
require_once '../pages/Header.php';

// Check if PDO connection exists
if (!isset($pdo)) {
    die("Database connection failed. Check connect.php.");
}

requireRole('parent');

$parent_id = $_SESSION['user_id'];
$habit_count = 0;
$error = '';

try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as habit_count FROM habits WHERE user_id = ?");
    $stmt->execute([$parent_id]);
    $habit_count = $stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("Database error in parent_dashboard.php: " . $e->getMessage());
    $error = "An error occurred while fetching habit count.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - Parent Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    
    <style>
        body {
            background-color: #FFFFFF;
            color: #2D3748;
        }
        .sidebar {
            background-color: #FFC107;
        }
        .sidebar a {
            color: #FFFFFF;
        }
        .sidebar a:hover {
            color: #FFD54F;
        }
        .content h1 {
            color: #FFC107;
        }
        .card {
            background-color: #FFF9C4;
            border: 1px solid #FFE082;
        }
        .btn {
            background-color: #FFC107;
        }
        .btn:hover {
            background-color: #FFB300;
        }
        .footer a {
            color: #FFD700;
        }
        .footer a:hover {
            color: #FFCA28;
        }
    </style>
    <!-- Google Translate Script -->
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script type="text/javascript">
    function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
    }
    </script>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <?php if (isset($_SESSION['role'])): ?>
            <?php if ($_SESSION['role'] === 'parent'): ?>
                <a href="parent_dashboard.php" class="block py-2 hover:text-FFD54F">Dashboard</a>
                <a href="manage_habits.php" class="block py-2 hover:text-FFD54F">Manage Habits</a>
                <a href="daily_log.php" class="block py-2 hover:text-FFD54F">Daily Log</a>
                <a href="weekly_record.php" class="block py-2 hover:text-FFD54F">Weekly Record</a>
                <a href="weekly_survey.php" class="block py-2 hover:text-FFD54F">Weekly Survey</a>
                <a href="profile.php" class="block py-2 hover:text-FFD54F">Profile</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php elseif ($_SESSION['role'] === 'ngo'): ?>
                <a href="ngo_dashboard.php" class="block py-2 hover:text-FFD54F">NGO Dashboard</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php endif; ?>
        <?php else: ?>
            <a href="login_parent.php" class="block py-2 hover:text-FFD54F">Parent Login</a>
            <a href="login_ngo.php" class="block py-2 hover:text-FFD54F">NGO Login</a>
            <a href="register.php" class="block py-2 hover:text-FFD54F">Register</a>
        <?php endif; ?>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div id="google_translate_element"></div>
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">Parent Dashboard</h1>
            <p class="text-lg md:text-xl mb-6">Manage your child's habits as of <span class="font-semibold"><?php echo date('h:i A T'); ?></span></p>
            <?php if (isset($error)): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>
        <div class="max-w-md mx-auto fade-in">
            <div class="card p-6">
                <p>You are managing <strong><?php echo htmlspecialchars($habit_count); ?></strong> habits for your child.</p>
                <p class="mt-4">Use the sidebar to track progress, log daily activities, and submit weekly surveys.</p>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <div id="google_translate_element"></div>
            <p class="text-2D3748">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-2D3748 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="hover:underline">Instagram</a>
                <!-- Google Translate Element -->
                <div id="google_translate_element"></div>
            </div>
        </div>
    </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-white text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>