<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../includes/requireRole.php';
require_once '../pages/Header.php';

// Check if PDO connection exists
if (!isset($pdo)) {
    die("Database connection failed. Check connect.php.");
}

requireRole('parent');

$parent_id = $_SESSION['user_id'] ?? null;
if (!$parent_id) {
    die("User not logged in or session invalid.");
}

$habits = [];
$error = '';

try {
    $stmt = $pdo->prepare("SELECT habit_id, habit_name, description FROM habits WHERE user_id = ?");
    $stmt->execute([$parent_id]);
    $habits = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Insert predefined habits
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_habit']) && isset($_POST['predefined_habits'])) {
        $selected_habits = array_map('trim', $_POST['predefined_habits']);
        foreach ($selected_habits as $habit_name) {
            if (!empty($habit_name)) {
                $stmt = $pdo->prepare("INSERT IGNORE INTO habits (user_id, habit_name, description) VALUES (?, ?, NULL)");
                $stmt->execute([$parent_id, $habit_name]);
            }
        }
        header("Location: manage_habits.php?success=1");
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_habit']) && !isset($_POST['predefined_habits'])) {
        $habit_name = filter_input(INPUT_POST, 'habit_name', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
        if (!empty($habit_name)) {
            $stmt = $pdo->prepare("INSERT INTO habits (user_id, habit_name, description) VALUES (?, ?, ?)");
            $stmt->execute([$parent_id, $habit_name, $description]);
            header("Location: manage_habits.php?success=1");
            exit;
        } else {
            $error = "Habit name cannot be empty.";
        }
    }
} catch (PDOException $e) {
    $errorMessage = "Database error in manage_habits.php: " . $e->getMessage();
    error_log($errorMessage);
    $error = "An error occurred while processing your request. Check server logs for details: " . substr($e->getMessage(), 0, 50) . "...";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - Manage Habits</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background-color: #FFFFFF;
            color: #2D3748;
        }
        .sidebar {
            background-color: #FFC107; /* Yellow */
        }
        .sidebar a {
            color: #FFFFFF;
        }
        .sidebar a:hover {
            color: #FFD54F; /* Lighter Yellow */
        }
        .content h1 {
            color: #FFC107; /* Yellow */
        }
        .card {
            background-color: #FFF9C4; /* Light Yellow */
            border: 1px solid #FFE082;
        }
        .btn {
            background-color: #FFC107; /* Yellow */
        }
        .btn:hover {
            background-color: #FFB300; /* Darker Yellow */
        }
        .footer a {
            color: #FFD700; /* Gold */
        }
        .footer a:hover {
            color: #FFCA28; /* Lighter Gold */
        }
    </style>
    <!-- Google Translate Script -->
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script type="text/javascript">
    function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
    }
    </script>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <?php if (isset($_SESSION['role'])): ?>
            <?php if ($_SESSION['role'] === 'parent'): ?>
                <a href="parent_dashboard.php" class="block py-2 hover:text-FFD54F">Dashboard</a>
                <a href="manage_habits.php" class="block py-2 hover:text-FFD54F">Manage Habits</a>
                <a href="daily_log.php" class="block py-2 hover:text-FFD54F">Daily Log</a>
                <a href="weekly_record.php" class="block py-2 hover:text-FFD54F">Weekly Record</a>
                <a href="weekly_survey.php" class="block py-2 hover:text-FFD54F">Weekly Survey</a>
                <a href="profile.php" class="block py-2 hover:text-FFD54F">Profile</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php elseif ($_SESSION['role'] === 'ngo'): ?>
                <a href="ngo_dashboard.php" class="block py-2 hover:text-FFD54F">NGO Dashboard</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php endif; ?>
        <?php else: ?>
            <a href="login_parent.php" class="block py-2 hover:text-FFD54F">Parent Login</a>
            <a href="login_ngo.php" class="block py-2 hover:text-FFD54F">NGO Login</a>
            <a href="register.php" class="block py-2 hover:text-FFD54F">Register</a>
        <?php endif; ?>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">Manage Habits</h1>
            <p class="text-lg md:text-xl mb-6">Manage your child's habits as of <span class="font-semibold"><?php echo date('h:i A T', strtotime('2025-07-09 13:57:00')); ?></span></p>
            <?php if (isset($error) && $error !== ''): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php elseif (isset($_GET['success'])): ?>
                <p class="text-green-600 mb-4">Habit added successfully!</p>
            <?php endif; ?>
        </div>
        <div class="max-w-md mx-auto fade-in">
            <!-- Add Habits Section -->
            <div class="card p-6 mb-6">
                <h3 class="text-lg font-semibold mb-4">Add Habits</h3>
                <form method="POST" class="space-y-4">
                    <?php
                    $predefined_habits = [
                        '🛏 Sleep Schedule' => [
                            'Make child sleep before 9 PM',
                            'Wake child before 7 AM',
                            'No screen time 1 hour before bed',
                            'Read a bedtime story',
                            'Ensure 8+ hours of sleep',
                            'No sugar before bed',
                            'Set a fixed bedtime routine',
                            'Brush teeth before sleeping'
                        ],
                        '🍎 Healthy Eating' => [
                            'Provide homemade breakfast',
                            'Include fruits in diet',
                            'Avoid junk food',
                            'Give 6–8 glasses of water',
                            'Encourage child to finish meal',
                            'Avoid sugary drinks',
                            'Eat meals on time',
                            'Involve child in food choices'
                        ],
                        '📚 Learning & Study Time' => [
                            'Help child with school homework',
                            'Practice reading for 15 minutes',
                            'Revise alphabets/numbers',
                            'Teach a new word',
                            'Practice drawing or colouring',
                            'Encourage curiosity questions',
                            'Revise 1 school topic',
                            'Tell an educational story',
                            'Limit study breaks'
                        ],
                        '🤝 Behavior & Values' => [
                            'Teach “Thank You” and “Sorry”',
                            'Practice sharing with siblings',
                            'Encourage kind behavior',
                            'Teach patience',
                            'Avoid shouting/scolding on child',
                            'Spend 5 mins on gratitude talk',
                            'Help child greet elders',
                            'Discuss one moral value',
                            'Praise good behavior'
                        ],
                        '🧘‍♀️ Physical Activity' => [
                            'Do morning walk or yoga',
                            'Take child for cycling',
                            'Play 30 minutes of outdoor games',
                            'Jumping/skipping indoors',
                            'Dance or movement game',
                            'Avoid full day sitting/screen time',
                            'Practice balance and coordination'
                        ],
                        '🎨 Fun & Creative Activities' => [
                            'Drawing or colouring',
                            'DIY or craft activity',
                            'Puzzle or building blocks',
                            'Sing a song together',
                            'Dance with child',
                            'Free play with toys',
                            'Create something using waste'
                        ],
                        '📱 Screen Time Management' => [
                            'Avoid screen time',
                            'Watch educational content only',
                            'No screen during meals',
                            'Discuss what they watched',
                            'Do 1 non-screen activity instead'
                        ],
                        '👪 Quality Family Time' => [
                            'Have 1 meal together',
                            'Talk about day with child',
                            'Play a board game or story time',
                            'Hug/cuddle child',
                            'Involve child in a chore',
                            'Go for a family walk'
                        ],
                        '🧼 Hygiene & Routine' => [
                            'Brush teeth twice',
                            'Bathe properly',
                            'Wash hands before/after eating',
                            'Trim nails weekly',
                            'Keep toys/books organized',
                            'Comb hair and dress neatly',
                            'Teach how to use toilet properly'
                        ],
                        '📅 Responsibility & Independence' => [
                            'Let child dress on their own',
                            'Let child pack their bag',
                            'Clean up after play',
                            'Feed self during meals',
                            'Involve child in small house task'
                        ]
                    ];

                    foreach ($predefined_habits as $category => $habits) {
                        echo "<div class='mb-4'>";
                        echo "<details class='select-none'>";
                        echo "<summary class='cursor-pointer font-semibold text-lg'>$category</summary>";
                        echo "<div class='mt-2 pl-4'>";
                        foreach ($habits as $habit) {
                            echo "<label class='block'><input type='checkbox' name='predefined_habits[]' value='$habit'> $habit</label>";
                        }
                        echo "</div>";
                        echo "</details>";
                        echo "</div>";
                    }
                    ?>
                    <button type="submit" name="add_habit" class="btn text-white p-2 rounded-lg w-full">Add Habit</button>
                </form>
            </div>

            <!-- Add Custom Habits Section -->
            <div class="card p-6">
                <h3 class="text-lg font-semibold mb-4">Add Custom Habits</h3>
                <form method="POST" class="space-y-4">
                    <div>
                        <label for="habit_name" class="block">Habit Name</label>
                        <input type="text" id="habit_name" name="habit_name" required class="w-full p-2 rounded-lg border border-FFE082">
                    </div>
                    <div>
                        <label for="description" class="block">Description</label>
                        <textarea id="description" name="description" class="w-full p-2 rounded-lg border border-FFE082" rows="3" placeholder="Enter habit description"></textarea>
                    </div>
                    <button type="submit" name="add_habit" class="btn text-white p-2 rounded-lg w-full">Add Habit</button>
                </form>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <p class="text-2D3748">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-2D3748 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="hover:underline">Instagram</a>
                <!-- Google Translate Element -->
                <div id="google_translate_element"></div>
            </div>
        </div>
    </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-white text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>