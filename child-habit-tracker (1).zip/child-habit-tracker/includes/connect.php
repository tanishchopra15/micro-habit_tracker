<?php
$host = 'localhost'; // cPanel uses localhost
$db = 'dsyjiawz_micro_habit_and_survey_insight'; // cPanel database name
$user = 'dsyjiawz_habit_tracker'; // Your cPanel database user
$pass = 'habit-tracker-survey-board'; // Replace with the user’s password
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>