<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../includes/requireRole.php';
require_once '../pages/Header.php';

requireRole('parent');

if (!isset($_SESSION['user_id']) || !$_SESSION['user_id']) {
    die("User not logged in or session invalid.");
}
$parent_id = $_SESSION['user_id'];

$error = '';
// Handle daily log form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['habit_id'], $_POST['status'])) {
    $habit_id = filter_input(INPUT_POST, 'habit_id', FILTER_VALIDATE_INT);
    $status = filter_input(INPUT_POST, 'status', FILTER_VALIDATE_INT);
    $completed_date = date('Y-m-d');

    if ($habit_id === false || $status === false || $status > 1 || $status < 0) {
        die("Invalid habit ID or status.");
    }

    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM habits WHERE habit_id = ? AND user_id = ?");
        $stmt->execute([$habit_id, $parent_id]);
        if ($stmt->fetchColumn() == 0) {
            die("Habit does not exist or does not belong to the user.");
        }

        $stmt = $pdo->prepare("SELECT * FROM habit_progress WHERE habit_id = ? AND user_id = ? AND completed_date = ?");
        $stmt->execute([$habit_id, $parent_id, $completed_date]);
        if ($stmt->fetch()) {
            $stmt = $pdo->prepare("UPDATE habit_progress SET status = ? WHERE habit_id = ? AND user_id = ? AND completed_date = ?");
            $stmt->execute([$status, $habit_id, $parent_id, $completed_date]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO habit_progress (habit_id, user_id, completed_date, status) VALUES (?, ?, ?, ?)");
            $stmt->execute([$habit_id, $parent_id, $completed_date, $status]);
        }

        header("Location: daily_log.php?success=1");
        exit;
    } catch (PDOException $e) {
        error_log("Database error in daily_log.php (log submission): " . $e->getMessage());
        $error = "An error occurred while submitting the log.";
    }
}

// Handle habit deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_habit_id'])) {
    $delete_habit_id = filter_input(INPUT_POST, 'delete_habit_id', FILTER_VALIDATE_INT);
    if ($delete_habit_id !== false) {
        try {
            $pdo->beginTransaction();
            $pdo->prepare("DELETE FROM habit_progress WHERE habit_id = ? AND user_id = ?")
                ->execute([$delete_habit_id, $parent_id]);
            $pdo->prepare("DELETE FROM habits WHERE habit_id = ? AND user_id = ?")
                ->execute([$delete_habit_id, $parent_id]);
            $pdo->commit();
            header("Location: daily_log.php?success=1");
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            header("Location: daily_log.php?error=1&msg=" . urlencode($e->getMessage()));
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Micro Habit Tracker - Daily Log</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body { background-color: #FFFFFF; color: #2D3748; }
        .sidebar { background-color: #FFC107; }
        .sidebar a { color: #FFFFFF; }
        .sidebar a:hover { color: #FFD54F; }
        .card { background-color: #FFF9C4; border: 1px solid #FFE082; }
        .btn { background-color: #FFC107; }
        .btn:hover { background-color: #FFB300; }
        .success-message { color: green; }
        .error-message { color: red; }
    </style>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" defer></script>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
        }
    </script>
</head>
<body class="min-h-screen flex flex-col">

<!-- Sidebar -->
<div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
    <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
    <a href="index.php" class="block py-2">Home</a>
    <a href="welcome.php" class="block py-2">Welcome</a>
    <a href="parent_dashboard.php" class="block py-2">Dashboard</a>
    <a href="manage_habits.php" class="block py-2">Manage Habits</a>
    <a href="daily_log.php" class="block py-2">Daily Log</a>
    <a href="weekly_record.php" class="block py-2">Weekly Record</a>
    <a href="weekly_survey.php" class="block py-2">Weekly Survey</a>
    <a href="profile.php" class="block py-2">Profile</a>
    <a href="../logout.php" class="block py-2">Logout</a>
    <div id="google_translate_element" class="mt-4"></div>
</div>

<!-- Main Content -->
<div class="content p-6 md:ml-64 flex-grow">
    <div class="text-center mb-8">
        <h1 class="text-4xl font-bold mb-2">Daily Habit Log</h1>
        <p class="text-lg">Today: <?php echo date('d M Y, h:i A'); ?></p>
        <?php if (isset($_GET['success'])): ?>
            <p class="success-message mt-2">Action completed successfully!</p>
        <?php elseif (isset($_GET['error'])): ?>
            <p class="error-message mt-2">Error: <?= htmlspecialchars($_GET['msg'] ?? 'Unknown error'); ?></p>
        <?php elseif ($error): ?>
            <p class="error-message mt-2"><?= htmlspecialchars($error); ?></p>
        <?php endif; ?>
    </div>

    <!-- Daily Log Form -->
    <div class="card p-6 max-w-md mx-auto mb-6">
        <form method="POST" class="space-y-4">
            <div>
                <label for="habit_id" class="block">Select Habit</label>
                <select name="habit_id" id="habit_id" required class="w-full p-2 rounded border border-yellow-400">
                    <?php
                    try {
                        $stmt = $pdo->prepare("SELECT habit_id, habit_name FROM habits WHERE user_id = ?");
                        $stmt->execute([$parent_id]);
                        $habits = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        if (empty($habits)) {
                            echo "<option value=''>No habits found. Add habits in Manage Habits.</option>";
                        } else {
                            foreach ($habits as $habit) {
                                echo "<option value='{$habit['habit_id']}'>{$habit['habit_name']}</option>";
                            }
                        }
                    } catch (PDOException $e) {
                        error_log("Database error in daily_log.php (habit selection): " . $e->getMessage());
                        echo "<option value=''>Error loading habits. Check server logs.</option>";
                    }
                    ?>
                </select>
            </div>
            <div>
                <label class="block">Status</label>
                <label><input type="radio" name="status" value="1" required> Completed</label>
                <label class="ml-4"><input type="radio" name="status" value="0"> Incomplete</label>
            </div>
            <button type="submit" class="btn text-white w-full p-2 rounded">Submit Log</button>
        </form>
    </div>

    <!-- Habit List with Delete Option -->
    <div class="card p-6 mb-8">
        <h2 class="text-xl font-bold mb-4">Latest Logs and Delete Habits</h2>
        <table class="w-full border-collapse">
            <thead>
                <tr class="bg-yellow-200">
                    <th class="p-2 border">Habit</th>
                    <th class="p-2 border">Last Status</th>
                    <th class="p-2 border">Last Date</th>
                    <th class="p-2 border">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                try {
                    $stmt = $pdo->prepare("
                        SELECT h.habit_id, h.habit_name,
                               (SELECT status FROM habit_progress hp WHERE hp.habit_id = h.habit_id AND hp.user_id = ? ORDER BY completed_date DESC LIMIT 1) AS last_status,
                               (SELECT completed_date FROM habit_progress hp WHERE hp.habit_id = h.habit_id AND hp.user_id = ? ORDER BY completed_date DESC LIMIT 1) AS last_date
                        FROM habits h
                        WHERE h.user_id = ?
                    ");
                    $stmt->execute([$parent_id, $parent_id, $parent_id]);
                    $habits = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if (empty($habits)) {
                        echo "<tr><td colspan='4' class='p-2 border text-center'>No habits found</td></tr>";
                    } else {
                        foreach ($habits as $habit) {
                            $statusText = $habit['last_status'] === null ? 'No Logs Yet' : ($habit['last_status'] ? 'Completed' : 'Incomplete');
                            $dateText = $habit['last_date'] ?? '—';
                            echo "<tr>";
                            echo "<td class='p-2 border'>{$habit['habit_name']}</td>";
                            echo "<td class='p-2 border'>{$statusText}</td>";
                            echo "<td class='p-2 border'>{$dateText}</td>";
                            echo "<td class='p-2 border'>";
                            echo "<form method='POST' onsubmit='return confirm(\"Are you sure to delete this habit?\");'>";
                            echo "<input type='hidden' name='delete_habit_id' value='{$habit['habit_id']}'>";
                            echo "<button type='submit' class='btn text-white px-3 py-1 rounded'>Delete</button>";
                            echo "</form>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    }
                } catch (PDOException $e) {
                    error_log("Database error in daily_log.php (habit list): " . $e->getMessage());
                    echo "<tr><td colspan='4' class='p-2 border text-center'>Error loading habit data</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Footer Section -->
    <div class="footer mt-12 text-center">
        <p class="text-gray-700">© 2025 SpaceECE India Foundation. All rights reserved.</p>
        <p class="text-gray-700 mt-2">Contact: <a href="https://www.spaceece.in" class="text-blue-600 underline">www.Spacece.in</a> | Phone: +91-90963-05648</p>
        <div class="mt-2">
            <a href="https://www.facebook.com/SpacECEIn" class="text-blue-700 hover:underline mr-4">Facebook</a>
            <a href="https://instagram.com/spac.ece" class="text-pink-600 hover:underline">Instagram</a>
        </div>
    </div>
</div>

<!-- Mobile Sidebar Toggle -->
<button class="md:hidden fixed top-4 left-4 bg-yellow-500 text-white text-xl p-2 rounded z-10"
        onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>

</body>
</html>