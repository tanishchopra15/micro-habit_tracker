<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../pages/Header.php';
session_start();

if (!isset($_SESSION['reset_username']) || !isset($_GET['token'])) {
    header("Location: forgot_password.php?error=1");
    exit;
}

$username = $_SESSION['reset_username'];
$token = $_GET['token'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = filter_input(INPUT_POST, 'new_password', FILTER_SANITIZE_STRING);
    $confirm_password = filter_input(INPUT_POST, 'confirm_password', FILTER_SANITIZE_STRING);

    // Validate password strength
    $password_regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/';
    if (!preg_match($password_regex, $new_password)) {
        $error = "Password must be at least 8 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character (!@#$%^&*).";
    } elseif ($new_password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        try {
            $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = ?");
            $stmt->execute([$password_hash, $username]);
            unset($_SESSION['reset_username']);
            unset($_SESSION['reset_token']);
            header("Location: login_parent.php?success=1");
            exit;
        } catch (PDOException $e) {
            $error = "Failed to update password: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - Change Password</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        body {
            background-color: #FFFFFF;
            color: #2D3748;
        }
        .sidebar {
            background-color: #FFC107; /* Yellow */
        }
        .sidebar a {
            color: #FFFFFF;
        }
        .sidebar a:hover {
            color: #FFD54F; /* Lighter Yellow */
        }
        .content h1 {
            color: #FFC107; /* Yellow */
        }
        .card {
            background-color: #FFF9C4; /* Light Yellow */
            border: 1px solid #FFE082;
        }
        .btn {
            background-color: #FFC107; /* Yellow */
        }
        .btn:hover {
            background-color: #FFB300; /* Darker Yellow */
        }
        .footer a {
            color: #FFD700; /* Gold */
        }
        .footer a:hover {
            color: #FFCA28; /* Lighter Gold */
        }
        .password-strength {
            margin-top: 0.5rem;
            font-size: 0.875rem;
        }
        .strength-weak { color: #E53E3E; }
        .strength-medium { color: #FFB300; }
        .strength-strong { color: #38A169; }
        .rule-satisfied::before {
            content: '✔ ';
            color: #38A169;
        }
        .rule-unsatisfied::before {
            content: '✖ ';
            color: #E53E3E;
        }
    </style>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" defer></script>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
        }
    </script>
    <script>
        function validatePassword() {
            const password = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const submitButton = document.querySelector('button[type="submit"]');
            const strengthIndicator = document.getElementById('password-strength');
            const rules = [
                { id: 'rule-length', regex: /.{8,}/, text: 'Minimum 8 characters' },
                { id: 'rule-uppercase', regex: /[A-Z]/, text: 'At least one uppercase letter' },
                { id: 'rule-lowercase', regex: /[a-z]/, text: 'At least one lowercase letter' },
                { id: 'rule-number', regex: /\d/, text: 'At least one number' },
                { id: 'rule-special', regex: /[!@#$%^&*]/, text: 'At least one special character (!@#$%^&*)' }
            ];

            let rulesMet = 0;
            rules.forEach(rule => {
                const ruleElement = document.getElementById(rule.id);
                if (rule.regex.test(password)) {
                    ruleElement.classList.remove('rule-unsatisfied');
                    ruleElement.classList.add('rule-satisfied');
                    rulesMet++;
                } else {
                    ruleElement.classList.remove('rule-satisfied');
                    ruleElement.classList.add('rule-unsatisfied');
                }
            });

            let strengthText = '';
            let strengthClass = '';
            if (rulesMet <= 2) {
                strengthText = 'Weak';
                strengthClass = 'strength-weak';
                submitButton.disabled = true;
            } else if (rulesMet <= 4) {
                strengthText = 'Medium';
                strengthClass = 'strength-medium';
                submitButton.disabled = true;
            } else {
                strengthText = 'Strong';
                strengthClass = 'strength-strong';
                submitButton.disabled = (password !== confirmPassword);
            }

            strengthIndicator.textContent = `Password Strength: ${strengthText}`;
            strengthIndicator.className = `password-strength ${strengthClass}`;

            const confirmPasswordField = document.getElementById('confirm_password');
            if (confirmPassword.length > 0 && password !== confirmPassword) {
                confirmPasswordField.classList.add('border-red-500');
            } else {
                confirmPasswordField.classList.remove('border-red-500');
            }
        }
    </script>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <a href="index.php" class="block mb-6">
            <img src="../assets/images/SpaceECE_Logo.jpg" alt="SpaceECE India Foundation Logo" class="sidebar-logo">
        </a>
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <a href="login_parent.php" class="block py-2 hover:text-FFD54F">Parent Login</a>
        <a href="login_ngo.php" class="block py-2 hover:text-FFD54F">NGO Login</a>
        <a href="register.php" class="block py-2 hover:text-FFD54F">Register</a>
        <div id="google_translate_element" class="mt-4"></div>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">Change Password</h1>
            <p class="text-lg md:text-xl text-white mb-6">Set a new password as of <span class="font-semibold"><?php echo date('h:i A T'); ?></span></p>
            <?php if (isset($error)): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>
        <div class="max-w-md mx-auto fade-in">
            <div class="card p-6 bg-white">
                <form method="POST" class="space-y-6">
                    <div>
                        <label for="new_password" class="block text-lg font-medium text-gray-700">New Password</label>
                        <input type="password" id="new_password" name="new_password" required class="w-full p-3 rounded-lg border border-gray-300" oninput="validatePassword()">
                        <div id="password-strength" class="password-strength">Password Strength: Weak</div>
                        <ul class="text-sm text-gray-600 mt-2 space-y-1">
                            <li id="rule-length" class="rule-unsatisfied">Minimum 8 characters</li>
                            <li id="rule-uppercase" class="rule-unsatisfied">At least one uppercase letter</li>
                            <li id="rule-lowercase" class="rule-unsatisfied">At least one lowercase letter</li>
                            <li id="rule-number" class="rule-unsatisfied">At least one number</li>
                            <li id="rule-special" class="rule-unsatisfied">At least one special character (!@#$%^&*)</li>
                        </ul>
                    </div>
                    <div>
                        <label for="confirm_password" class="block text-lg font-medium text-gray-700">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required class="w-full p-3 rounded-lg border border-gray-300" oninput="validatePassword()">
                    </div>
                    <button type="submit" class="w-full btn bg-purple-600 text-white p-3 rounded-lg hover:bg-purple-700" disabled>Change Password</button>
                </form>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <p class="text-gray-600">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-gray-600 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="text-purple-600 hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="text-purple-600 hover:underline">Instagram</a>
            </div>
        </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-black text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>