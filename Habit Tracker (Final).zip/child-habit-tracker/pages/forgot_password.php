<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../pages/Header.php';
session_start();

$error = '';
if (isset($_GET['error']) && $_GET['error'] == 1) {
    $error = "Invalid username or security answer.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $security_question = filter_input(INPUT_POST, 'security_question', FILTER_SANITIZE_STRING);
    $security_answer = filter_input(INPUT_POST, 'security_answer', FILTER_SANITIZE_STRING);

    try {
        $stmt = $pdo->prepare("SELECT security_question, security_answer FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && $user['security_question'] === $security_question && $user['security_answer'] === $security_answer) {
            $_SESSION['reset_username'] = $username;
            $_SESSION['reset_token'] = bin2hex(random_bytes(16));
            header("Location: change_password.php?token=" . $_SESSION['reset_token']);
            exit;
        } else {
            $error = "Invalid username, security question, or answer.";
        }
    } catch (PDOException $e) {
        $error = "An error occurred: " . htmlspecialchars($e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        body {
            background-color: #FFFFFF;
            color: #2D3748;
        }
        .sidebar {
            background-color: #FFC107; /* Yellow */
        }
        .sidebar a {
            color: #FFFFFF;
        }
        .sidebar a:hover {
            color: #FFD54F; /* Lighter Yellow */
        }
        .content h1 {
            color: #FFC107; /* Yellow */
        }
        .card {
            background-color: #FFF9C4; /* Light Yellow */
            border: 1px solid #FFE082;
        }
        .btn {
            background-color: #FFC107; /* Yellow */
        }
        .btn:hover {
            background-color: #FFB300; /* Darker Yellow */
        }
        .footer a {
            color: #FFD700; /* Gold */
        }
        .footer a:hover {
            color: #FFCA28; /* Lighter Gold */
        }
    </style>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit" defer></script>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
        }
    </script>
    <script>
        function validateForm() {
            const username = document.getElementById('username').value;
            const securityQuestion = document.getElementById('security_question').value;
            const securityAnswer = document.getElementById('security_answer').value;
            const submitButton = document.querySelector('button[type="submit"]');
            submitButton.disabled = !(username && securityQuestion && securityAnswer);
        }
    </script>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <a href="index.php" class="block mb-6">
            <img src="../assets/images/SpaceECE_Logo.jpg" alt="SpaceECE India Foundation Logo" class="sidebar-logo">
        </a>
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <a href="login_parent.php" class="block py-2 hover:text-FFD54F">Parent Login</a>
        <a href="login_ngo.php" class="block py-2 hover:text-FFD54F">NGO Login</a>
        <a href="register.php" class="block py-2 hover:text-FFD54F">Register</a>
        <div id="google_translate_element" class="mt-4"></div>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">Forgot Password</h1>
            <p class="text-lg md:text-xl text-white mb-6">Verify your identity as of <span class="font-semibold"><?php echo date('h:i A T'); ?></span></p>
            <?php if ($error): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>
        <div class="max-w-md mx-auto fade-in">
            <div class="card p-6 bg-white">
                <form method="POST" class="space-y-6">
                    <div>
                        <label for="username" class="block text-lg font-medium text-gray-700">Username</label>
                        <input type="text" id="username" name="username" required class="w-full p-3 rounded-lg border border-gray-300" oninput="validateForm()">
                    </div>
                    <div>
                        <label for="security_question" class="block text-lg font-medium text-gray-700">Security Question</label>
                        <select id="security_question" name="security_question" required class="w-full p-3 rounded-lg border border-gray-300" oninput="validateForm()">
                            <option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
                            <option value="What was the name of your first pet?">What was the name of your first pet?</option>
                            <option value="What was the name of your elementary school?">What was the name of your elementary school?</option>
                        </select>
                    </div>
                    <div>
                        <label for="security_answer" class="block text-lg font-medium text-gray-700">Security Answer</label>
                        <input type="text" id="security_answer" name="security_answer" required class="w-full p-3 rounded-lg border border-gray-300" oninput="validateForm()">
                    </div>
                    <button type="submit" class="w-full btn bg-purple-600 text-white p-3 rounded-lg hover:bg-purple-700" disabled>Verify</button>
                </form>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <p class="text-gray-600">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-gray-600 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="text-purple-600 hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="text-purple-600 hover:underline">Instagram</a>
            </div>
        </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-black text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>