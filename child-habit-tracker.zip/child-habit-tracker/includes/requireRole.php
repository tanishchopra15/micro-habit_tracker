<?php
require_once '../includes/connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function requireRole($requiredRole) {
    // Check if PDO connection exists
    if (!isset($GLOBALS['pdo'])) {
        error_log("Database connection failed in requireRole.php");
        header("Location: ../pages/error.php"); // Placeholder; create error.php if needed
        exit;
    }

    $current_script = basename($_SERVER['PHP_SELF']);
    
    // Allow both 'parent' and 'ngo' roles for profile.php
    if ($current_script === 'profile.php') {
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || !in_array($_SESSION['role'], ['parent', 'ngo'])) {
            $redirect = (isset($_SESSION['role']) && $_SESSION['role'] === 'ngo') ? 'login_ngo.php' : 'login_parent.php';
            header("Location: ../pages/$redirect");
            exit;
        }
    } else {
        // For other pages, require the specified role
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== $requiredRole) {
            $redirect = $requiredRole === 'parent' ? 'login_parent.php' : 'login_ngo.php';
            header("Location: ../pages/$redirect");
            exit;
        }
    }
}
?>