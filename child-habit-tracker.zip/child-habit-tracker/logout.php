<?php
date_default_timezone_set('Asia/Kolkata');
require_once 'includes/connect.php';
session_start();
session_destroy();
header("Location: pages/index.php");
exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - Logout</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="animated-bg min-h-screen">
    <!-- No content needed as it redirects -->
</body>
</html>