<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../includes/requireRole.php';

requireRole('ngo');

$surveys = [];
$daily_logs = [];
$weekly_records = [];

try {
    // Fetch survey data
    $stmt = $pdo->prepare("SELECT s.*, u.username FROM surveys s JOIN users u ON s.user_id = u.user_id ORDER BY s.survey_date DESC");
    $stmt->execute();
    $surveys = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch daily logs for all parents (only for today)
    $today = new DateTime();
    $stmt = $pdo->prepare("
        SELECT h.habit_id, u.username, h.habit_name, 
               COALESCE(hp.completed_date, ?) AS completed_date, 
               COALESCE(hp.status, 0) AS status
        FROM habits h
        JOIN users u ON h.user_id = u.user_id
        LEFT JOIN habit_progress hp ON h.habit_id = hp.habit_id 
            AND hp.user_id = h.user_id 
            AND hp.completed_date = ?
        WHERE u.role = 'parent'
        ORDER BY u.username, h.habit_name
    ");
    $stmt->execute([$today->format('Y-m-d'), $today->format('Y-m-d')]);
    $daily_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch weekly records for all parents (last 7 days)
    $start_date = clone $today;
    $start_date->modify('-6 days'); // Start from 7 days ago
    $end_date = clone $today;
    $stmt = $pdo->prepare("
        SELECT h.habit_id, u.username, h.habit_name, 
               hp.completed_date, COALESCE(hp.status, 0) AS status
        FROM habits h
        JOIN users u ON h.user_id = u.user_id
        LEFT JOIN habit_progress hp ON h.habit_id = hp.habit_id 
            AND hp.user_id = h.user_id 
            AND hp.completed_date BETWEEN ? AND ?
        WHERE u.role = 'parent'
        ORDER BY u.username, h.habit_name, hp.completed_date DESC
    ");
    $stmt->execute([$start_date->format('Y-m-d'), $end_date->format('Y-m-d')]);
    $weekly_records = [];
    $current_habit = null;
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $record) {
        if ($current_habit !== $record['habit_id']) {
            $weekly_records[$record['habit_id']] = [
                'username' => $record['username'],
                'habit_name' => $record['habit_name'],
                'days' => []
            ];
            $date = clone $start_date;
            while ($date <= $end_date) {
                $weekly_records[$record['habit_id']]['days'][$date->format('Y-m-d')] = 'Not Recorded';
                $date->modify('+1 day');
            }
            $current_habit = $record['habit_id'];
        }
        if ($record['completed_date']) {
            $weekly_records[$record['habit_id']]['days'][$record['completed_date']] = $record['status'] ? 'Completed' : 'Incomplete';
        }
    }
} catch (PDOException $e) {
    error_log("Database error in ngo_dashboard.php: " . $e->getMessage());
    $error = "An error occurred while fetching data.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - NGO Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { background-color: #FFFFFF; color: #2D3748; }
        .sidebar { background-color: #FFC107; }
        .sidebar a { color: #FFFFFF; }
        .sidebar a:hover { color: #FFD54F; }
        .content h1 { color: #FFC107; }
        .card { background-color: #FFF9C4; border: 1px solid #FFE082; }
        .btn { background-color: #FFC107; }
        .btn:hover { background-color: #FFB300; }
        .profile-btn { background-color: #4B5563; color: white; }
        .profile-btn:hover { background-color: #374151; }
        .footer a { color: #FFD700; }
        .footer a:hover { color: #FFCA28; }
        .status-completed { color: #38A169; }
        .status-incomplete { color: #E53E3E; }
    </style>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <a href="ngo_dashboard.php" class="block py-2 hover:text-FFD54F">NGO Dashboard</a>
        <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">NGO Dashboard</h1>
            <p class="text-lg md:text-xl mb-6">Data as of <span class="font-semibold"><?php echo date('h:i A T'); ?></span></p>
            <?php if (isset($error)): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>
        <div class="max-w-4xl mx-auto fade-in space-y-8">
            <!-- Parent Feedback Section -->
            <div class="card p-6">
                <h3 class="text-lg font-semibold mb-4">Parent Feedback</h3>
                <?php if (empty($surveys)): ?>
                    <p>No survey submissions available.</p>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead>
                                <tr class="bg-gray-200">
                                    <th class="p-2 border">Parent</th>
                                    <th class="p-2 border">Ease of Habits</th>
                                    <th class="p-2 border">Challenges</th>
                                    <th class="p-2 border">Date</th>
                                    <th class="p-2 border">Profile</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($surveys as $survey): ?>
                                    <tr>
                                        <td class="p-2 border"><?php echo htmlspecialchars($survey['username']); ?></td>
                                        <td class="p-2 border"><?php echo htmlspecialchars($survey['ease_of_habits']); ?>/5</td>
                                        <td class="p-2 border"><?php echo htmlspecialchars($survey['challenges']); ?></td>
                                        <td class="p-2 border"><?php echo htmlspecialchars($survey['survey_date']); ?></td>
                                        <td class="p-2 border">
                                            <a href="profile.php?user_id=<?php echo $survey['user_id']; ?>&view=1" class="profile-btn p-2 rounded-lg text-sm">View Profile</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Daily Logs Section -->
            <div class="card p-6">
                <h3 class="text-lg font-semibold mb-4">Daily Logs (<?php echo $today->format('d M Y'); ?>)</h3>
                <?php if (empty($daily_logs)): ?>
                    <p>No daily logs available for today.</p>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead>
                                <tr class="bg-gray-200">
                                    <th class="p-2 border">Parent</th>
                                    <th class="p-2 border">Habit</th>
                                    <th class="p-2 border">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $logs_by_user = [];
                                foreach ($daily_logs as $log) {
                                    $key = $log['username'] . '|' . $log['habit_name'];
                                    if (!isset($logs_by_user[$key])) {
                                        $logs_by_user[$key] = $log;
                                    }
                                }
                                foreach ($logs_by_user as $log): ?>
                                    <tr>
                                        <td class="p-2 border"><?php echo htmlspecialchars($log['username']); ?></td>
                                        <td class="p-2 border"><?php echo htmlspecialchars($log['habit_name']); ?></td>
                                        <td class="p-2 border <?php echo $log['status'] ? 'status-completed' : 'status-incomplete'; ?>">
                                            <?php echo $log['status'] ? 'Completed' : 'Incomplete'; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Weekly Records Section -->
            <div class="card p-6">
                <h3 class="text-lg font-semibold mb-4">Weekly Records (<?php echo $start_date->format('d M Y') . ' - ' . $end_date->format('d M Y'); ?>)</h3>
                <?php if (empty($weekly_records)): ?>
                    <p>No weekly records available for this week.</p>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead>
                                <tr class="bg-gray-200">
                                    <th class="p-2 border">Parent</th>
                                    <th class="p-2 border">Habit</th>
                                    <?php
                                    $date = clone $start_date;
                                    while ($date <= $end_date) {
                                        echo "<th class='p-2 border'>" . $date->format('d M') . "</th>";
                                        $date->modify('+1 day');
                                    }
                                    ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($weekly_records as $record): ?>
                                    <tr>
                                        <td class="p-2 border"><?php echo htmlspecialchars($record['username']); ?></td>
                                        <td class="p-2 border"><?php echo htmlspecialchars($record['habit_name']); ?></td>
                                        <?php
                                        $days = $record['days'];
                                        $date = clone $start_date;
                                        while ($date <= $end_date) {
                                            $day_key = $date->format('Y-m-d');
                                            $status = $days[$day_key];
                                            echo "<td class='p-2 border " . ($status === 'Completed' ? 'status-completed' : 'status-incomplete') . "'>$status</td>";
                                            $date->modify('+1 day');
                                        }
                                        ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <p class="text-2D3748">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-2D3748 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="hover:underline">Instagram</a>
            </div>
        </div>
    </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-white text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>