<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../includes/requireRole.php';

requireRole('parent');

$parent_id = $_SESSION['user_id'];
$error = '';
try {
    $stmt = $pdo->prepare("SELECT habit_id, habit_name FROM habits WHERE user_id = ?");
    $stmt->execute([$parent_id]);
    $habits = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching habits in weekly_record.php: " . $e->getMessage());
    $error = "An error occurred while fetching habits.";
}

$current_date = new DateTime();
$monday = clone $current_date;
$monday->modify('this week Monday');
$sunday = clone $current_date;
$sunday->modify('this week Sunday');
$week_dates = [];
$date = clone $monday;
while ($date <= $sunday) {
    $week_dates[$date->format('Y-m-d')] = $date->format('l, d M Y');
    $date->modify('+1 day');
}

$progress_data = [];
if (!empty($habits)) {
    $habit_ids = array_column($habits, 'habit_id');
    $placeholders = implode(',', array_fill(0, count($habit_ids), '?'));
    try {
        $stmt = $pdo->prepare("SELECT habit_id, completed_date, status FROM habit_progress WHERE habit_id IN ($placeholders) AND completed_date >= ? AND completed_date <= ?");
        $stmt->execute(array_merge($habit_ids, [$monday->format('Y-m-d'), $sunday->format('Y-m-d')]));
        $progress = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($progress as $record) {
            $progress_data[$record['habit_id']][$record['completed_date']] = $record['status'] == 1 ? 'completed' : 'incomplete';
        }
    } catch (PDOException $e) {
        error_log("Error fetching progress in weekly_record.php: " . $e->getMessage());
        $error = "An error occurred while fetching progress data.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - Weekly Record</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background-color: #FFFFFF;
            color: #2D3748;
        }
        .sidebar {
            background-color: #FFC107;
        }
        .sidebar a {
            color: #FFFFFF;
        }
        .sidebar a:hover {
            color: #FFD54F;
        }
        .content h1 {
            color: #FFC107;
        }
        .card {
            background-color: #FFF9C4;
            border: 1px solid #FFE082;
        }
        .btn {
            background-color: #FFC107;
        }
        .btn:hover {
            background-color: #FFB300;
        }
        .footer a {
            color: #FFD700;
        }
        .footer a:hover {
            color: #FFCA28;
        }
    </style>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <a href="index.php" class="block mb-6">
             <img src="../assets/images/SpaceECE_Logo.jpg" alt="SpaceECE India Foundation Logo" class="sidebar-logo">
        </a>
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <?php if (isset($_SESSION['role'])): ?>
            <?php if ($_SESSION['role'] === 'parent'): ?>
                <a href="parent_dashboard.php" class="block py-2 hover:text-FFD54F">Dashboard</a>
                <a href="manage_habits.php" class="block py-2 hover:text-FFD54F">Manage Habits</a>
                <a href="daily_log.php" class="block py-2 hover:text-FFD54F">Daily Log</a>
                <a href="weekly_record.php" class="block py-2 hover:text-FFD54F">Weekly Record</a>
                <a href="weekly_survey.php" class="block py-2 hover:text-FFD54F">Weekly Survey</a>
                <a href="profile.php" class="block py-2 hover:text-FFD54F">Profile</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php elseif ($_SESSION['role'] === 'ngo'): ?>
                <a href="ngo_dashboard.php" class="block py-2 hover:text-FFD54F">NGO Dashboard</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php endif; ?>
        <?php else: ?>
            <a href="login_parent.php" class="block py-2 hover:text-FFD54F">Parent Login</a>
            <a href="login_ngo.php" class="block py-2 hover:text-FFD54F">NGO Login</a>
            <a href="register.php" class="block py-2 hover:text-FFD54F">Register</a>
        <?php endif; ?>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">Weekly Record</h1>
            <p class="text-lg md:text-xl mb-6">View your child's habit progress as of <span class="font-semibold"><?php echo date('h:i A T'); ?></span></p>
            <?php if (isset($error)): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>
        <div class="max-w-3xl mx-auto fade-in">
            <?php if (empty($habits)): ?>
                <div class="card p-6">
                    <p>No habits have been added yet. Please add habits in the <a href="manage_habits.php" class="text-48BB78 hover:underline">Manage Habits</a> section.</p>
                </div>
            <?php else: ?>
                <?php foreach ($habits as $habit): ?>
                    <div class="card p-6 mb-4">
                        <h2 class="text-xl font-semibold mb-2"><?php echo htmlspecialchars($habit['habit_name']); ?></h2>
                        <ul class="list-disc pl-5">
                            <?php foreach ($week_dates as $date => $label): ?>
                                <li>
                                    <?php echo $label; ?>: 
                                    <?php
                                    $current_date_str = date('Y-m-d');
                                    if (isset($progress_data[$habit['habit_id']][$date])) {
                                        $status = $progress_data[$habit['habit_id']][$date];
                                        $status_text = ucfirst($status);
                                        $status_color = ($status === 'completed') ? 'style="color: #38A169;"' : 'style="color: #E53E3E;"';
                                        echo "<span $status_color>$status_text</span>";
                                    } elseif ($date <= $current_date_str) {
                                        echo '<span style="color: #E53E3E;">Incomplete</span>';
                                    } else {
                                        echo " (Future date)";
                                    }
                                    ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="footer mt-12 text-center">
            <p class="text-2D3748">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-2D3748 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="hover:underline">Instagram</a>
            </div>
        </div>
    </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-white text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>