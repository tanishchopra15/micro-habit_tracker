<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

    $stmt = $pdo->prepare("SELECT user_id, password_hash, role FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password_hash']) && $user['role'] === 'ngo') {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['role'] = $user['role'];
        header("Location: ngo_dashboard.php");
        exit;
    } else {
        $error = "Invalid username or password, or not an NGO account.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - NGO Login</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background-color: #FFFFFF;
            color: #2D3748;
        }
        .sidebar {
            background-color: #FFC107; /* Yellow */
        }
        .sidebar a {
            color: #FFFFFF;
        }
        .sidebar a:hover {
            color: #FFD54F; /* Lighter Yellow */
        }
        .content h1 {
            color: #FFC107; /* Yellow */
        }
        .card {
            background-color: #FFF9C4; /* Light Yellow */
            border: 1px solid #FFE082;
        }
        .btn {
            background-color: #FFC107; /* Yellow */
        }
        .btn:hover {
            background-color: #FFB300; /* Darker Yellow */
        }
        .footer a {
            color: #FFD700; /* Gold */
        }
        .footer a:hover {
            color: #FFCA28; /* Lighter Gold */
        }
    </style>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <h2 class="text-2xl font-bold mb-6 text-center text-2D3748">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <?php if (isset($_SESSION['role'])): ?>
            <?php if ($_SESSION['role'] === 'parent'): ?>
                <a href="parent_dashboard.php" class="block py-2 hover:text-FFD54F">Dashboard</a>
                <a href="manage_habits.php" class="block py-2 hover:text-FFD54F">Manage Habits</a>
                <a href="daily_log.php" class="block py-2 hover:text-FFD54F">Daily Log</a>
                <a href="weekly_record.php" class="block py-2 hover:text-FFD54F">Weekly Record</a>
                <a href="weekly_survey.php" class="block py-2 hover:text-FFD54F">Weekly Survey</a>
                <a href="profile.php" class="block py-2 hover:text-FFD54F">Profile</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php elseif ($_SESSION['role'] === 'ngo'): ?>
                <a href="ngo_dashboard.php" class="block py-2 hover:text-FFD54F">NGO Dashboard</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php endif; ?>
        <?php else: ?>
            <a href="login_parent.php" class="block py-2 hover:text-FFD54F">Parent Login</a>
            <a href="login_ngo.php" class="block py-2 hover:text-FFD54F">NGO Login</a>
            <a href="register.php" class="block py-2 hover:text-FFD54F">Register</a>
        <?php endif; ?>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">NGO Login</h1>
            <p class="text-lg md:text-xl mb-6">Log in as of <span class="font-semibold"><?php echo date('h:i A T'); ?></span></p>
            <?php if (isset($error)): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>
        <div class="max-w-md mx-auto fade-in">
            <div class="card p-6">
                <form method="POST" class="space-y-6">
                    <div>
                        <label for="username" class="block text-lg font-medium">Username</label>
                        <input type="text" id="username" name="username" required class="w-full p-3 rounded-lg border border-FFE082">
                    </div>
                    <div>
                        <label for="password" class="block text-lg font-medium">Password</label>
                        <input type="password" id="password" name="password" required class="w-full p-3 rounded-lg border border-FFE082">
                    </div>
                    <button type="submit" class="w-full btn text-2D3748 p-3 rounded-lg">Login</button>
                </form>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <p>© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="hover:underline">Instagram</a>
            </div>
        </div>
    </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-2D3748 text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>