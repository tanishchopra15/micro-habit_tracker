<?php
date_default_timezone_set('Asia/Kolkata');
require_once '../includes/connect.php';
require_once '../includes/requireRole.php';

requireRole('parent');

$parent_id = $_SESSION['user_id'];
$error = '';
$success = isset($_GET['success']) ? "Survey submitted successfully!" : '';
if (isset($_GET['error'])) {
    $error = $_GET['error'] == 1 ? "An error occurred while submitting the survey. Check server logs." :
            ($_GET['error'] == 2 ? "Please provide valid input for ease of habits and challenges." : "Unknown error occurred.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Micro Habit Tracker - Weekly Survey</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            background-color: #FFFFFF;
            color: #2D3748;
        }
        .sidebar {
            background-color: #FFC107;
        }
        .sidebar a {
            color: #FFFFFF;
        }
        .sidebar a:hover {
            color: #FFD54F;
        }
        .content h1 {
            color: #FFC107;
        }
        .card {
            background-color: #FFF9C4;
            border: 1px solid #FFE082;
        }
        .btn {
            background-color: #FFC107;
        }
        .btn:hover {
            background-color: #FFB300;
        }
        .footer a {
            color: #FFD700;
        }
        .footer a:hover {
            color: #FFCA28;
        }
    </style>
</head>
<body class="animated-bg min-h-screen">
    <div class="sidebar fixed left-0 top-0 h-full w-64 p-4 hidden md:block">
        <a href="index.php" class="block mb-6">
            <img src="../assets/images/SpaceECE_Logo.jpg" alt="SpaceECE India Foundation Logo" class="sidebar-logo">
        </a>
        <h2 class="text-2xl font-bold mb-6 text-center text-white">Micro Habit Tracker</h2>
        <a href="index.php" class="block py-2 hover:text-FFD54F">Home</a>
        <a href="welcome.php" class="block py-2 hover:text-FFD54F">Welcome</a>
        <?php if (isset($_SESSION['role'])): ?>
            <?php if ($_SESSION['role'] === 'parent'): ?>
                <a href="parent_dashboard.php" class="block py-2 hover:text-FFD54F">Dashboard</a>
                <a href="manage_habits.php" class="block py-2 hover:text-FFD54F">Manage Habits</a>
                <a href="daily_log.php" class="block py-2 hover:text-FFD54F">Daily Log</a>
                <a href="weekly_record.php" class="block py-2 hover:text-FFD54F">Weekly Record</a>
                <a href="weekly_survey.php" class="block py-2 hover:text-FFD54F">Weekly Survey</a>
                <a href="profile.php" class="block py-2 hover:text-FFD54F">Profile</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php elseif ($_SESSION['role'] === 'ngo'): ?>
                <a href="ngo_dashboard.php" class="block py-2 hover:text-FFD54F">NGO Dashboard</a>
                <a href="../logout.php" class="block py-2 hover:text-FFD54F">Logout</a>
            <?php endif; ?>
        <?php else: ?>
            <a href="login_parent.php" class="block py-2 hover:text-FFD54F">Parent Login</a>
            <a href="login_ngo.php" class="block py-2 hover:text-FFD54F">NGO Login</a>
            <a href="register.php" class="block py-2 hover:text-FFD54F">Register</a>
        <?php endif; ?>
    </div>
    <div class="content flex-1 p-6 md:ml-64">
        <div class="text-center py-12">
            <h1 class="text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">Weekly Survey</h1>
            <p class="text-lg md:text-xl mb-6">Submit your feedback as of <span class="font-semibold"><?php echo date('h:i A T', strtotime('2025-07-09 14:22:00')); ?></span></p>
            <?php if ($error): ?>
                <p class="text-red-600 mb-4"><?php echo htmlspecialchars($error); ?></p>
            <?php elseif ($success): ?>
                <p class="text-green-600 mb-4"><?php echo htmlspecialchars($success); ?></p>
            <?php endif; ?>
        </div>
        <div class="max-w-md mx-auto fade-in">
            <div class="card p-6">
                <form method="POST" action="submit_survey.php" class="space-y-4">
                    <div>
                        <label class="block">Ease of Habits (1-5)</label>
                        <select name="ease_of_habits" required class="w-full p-2 rounded-lg border border-FFE082">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div>
                        <label for="challenges" class="block">Challenges</label>
                        <textarea id="challenges" name="challenges" required class="w-full p-2 rounded-lg border border-FFE082" rows="4"></textarea>
                    </div>
                    <button type="submit" name="submit_survey" class="btn text-white p-2 rounded-lg w-full">Submit Survey</button>
                </form>
            </div>
        </div>
        <div class="footer mt-12 text-center">
            <p class="text-2D3748">© 2025 SpaceECE India Foundation. All rights reserved.</p>
            <p class="text-2D3748 mt-2">Contact: www.spacece.in | Phone: +91-90963-05648</p>
            <div class="mt-2">
                <a href="https://www.facebook.com/SpacECEIn" class="hover:underline mr-4">Facebook</a>
                <a href="https://instagram.com/spac.ece" class="hover:underline">Instagram</a>
            </div>
        </div>
    </div>
    <button class="sidebar-toggle md:hidden fixed top-4 left-4 text-white text-2xl z-10" onclick="document.querySelector('.sidebar').classList.toggle('block')">☰</button>
</body>
</html>